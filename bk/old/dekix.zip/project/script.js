/*
This is a JavaScript (JS) file.
JavaScript is the programming language that powers the web.

To use this file, place the following <script> tag just before the closing </body> tag in your HTML file, making sure that the filename after "src" matches the name of your file...

    <script src="script.js"></script>

Learn more about JavaScript at https://developer.mozilla.org/en-US/Learn/JavaScript

When you're done, you can delete all of this grey text, it's just a comment.
*/

<script>
  <!--
  function getStylesheet() {
  var currentTime = new Date().getHours();
  if (0 <= currentTime&&currentTime < 7) {
    document.write("<link rel='stylesheet' href='night.css' type='text/css'>");
  }
  if (7 <= currentTime&&currentTime < 19) {
    document.write("<link rel='stylesheet' href='day.css' type='text/css'>");
  }
  if (19 <= currentTime&&currentTime < 24) {
    document.write("<link rel='stylesheet' href='night.css' type='text/css'>");
  }
}

getStylesheet();
-->
  </script>

<noscript><link href="night.css" rel="stylesheet"></noscript>